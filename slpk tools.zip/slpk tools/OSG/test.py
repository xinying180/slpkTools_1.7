import string
import subprocess


def RunCexe(exePath,sourceFilePath):
    args = [exePath, sourceFilePath]
    p=subprocess.Popen(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE, shell=True)
    p.wait()
exePath = r'C:\Users\admin\Desktop\osg_test\CheckOSGBFile.exe'
osgbFolderPath = r"E:\osgb\xurukun_shemi\osgbtest\test\obuildings0\Data"
RunCexe(exePath,osgbFolderPath)

print("success")
